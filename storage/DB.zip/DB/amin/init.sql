-- creating tables in order P then C
\i Products.sql
\i Clients.sql
\i Triggers.sql
